package com.example.nandkishorjindal.usersdetails;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private ListView list_view;
    private DatabaseReference databaseReference;
    private FirebaseDatabase firebaseDatabase;

    private List<Users> usersList;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        list_view = (ListView) findViewById(R.id.listView);

        usersList =new ArrayList<>();
        databaseReference = FirebaseDatabase.getInstance().getReference("UserDetails");

      //  firebaseDatabase = FirebaseDatabase.getInstance();


    }
    @Override
    protected void onStart() {
        super.onStart();

        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                usersList.clear();
               for(DataSnapshot usersSnapshot: dataSnapshot.getChildren()){

                   Users users = usersSnapshot.getValue(Users.class);
                   usersList.add(users);


               }
                Users_list adapter = new Users_list(MainActivity.this,usersList);
               list_view.setAdapter(adapter);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

    }

}
