package com.example.nandkishorjindal.usersdetails;

public class Users {

    public String name,collegeName,year;
    public boolean status;

    public Users(){

    }

    public String getName(){
        return name;
    }
    public String getCollegeName(){
        return collegeName;
    }
    public String getYear(){
        return year;
    }
    public boolean getstatus(){
        return status;
    }





}
